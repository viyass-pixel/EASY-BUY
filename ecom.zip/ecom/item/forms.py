from django import forms
from .models import Item

Inputclasses= 'w-full py-4 px-6 rounded-xl border'
class NewItemForm(forms.ModelForm):
    class Meta:
        model = Item
        fields = ('category', 'name', 'description', 'price', 'image',)
        widgets = {
            'category': forms.Select(attrs={
                'class': Inputclasses
            }),
            'name': forms.TextInput(attrs={
                'class': Inputclasses
            }),
            'description': forms.Textarea(attrs={
                'class': Inputclasses
            }),
            'price': forms.TextInput(attrs={
                'class': Inputclasses
            }),
            'image': forms.FileInput(attrs={
                'class': Inputclasses
            })
        }

class EditItemForm(forms.ModelForm):
    class Meta:
        model = Item
        fields = ('name','description','price','image', 'is_sold')

        widgets = {
            'name':forms.Select(attrs={
                'class': Inputclasses
        }),
            'description':forms.Select(attrs={
                'class': Inputclasses
        }),
            'price':forms.Select(attrs={
                'class': Inputclasses
        }),
            'image':forms.Select(attrs={
                'class': Inputclasses
        })}